def classFactory(iface):
    from .weedsdeep_processing import WeedsDeep
    return WeedsDeep(iface)
